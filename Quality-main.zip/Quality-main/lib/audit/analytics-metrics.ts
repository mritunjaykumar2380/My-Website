import { PASS_RATE_QUALITY_THRESHOLD } from "@/lib/audit/metrics-config";
import { resolveMetricDate } from "@/lib/audit/metric-dates";
import type { FeedbackSecurity } from "@/lib/audit/feedback";
import type { AuditRow, CategoryScore } from "@/lib/audit/types";
import {
  canonicalCategoryKey,
  canonicalCategoryLabel,
  metricGroupKey,
  pickDisplayName,
  resolveParameterGroupKey,
} from "@/lib/audit/analytics-metric-keys";

export type AnalyticsAggregationOptions = {
  mergeParametersAcrossInteractionTypes: boolean;
};

const DEFAULT_AGGREGATION_OPTIONS: AnalyticsAggregationOptions = {
  mergeParametersAcrossInteractionTypes: false,
};

export type AnalyticsAuditRecord = {
  id: string;
  agent: string;
  supervisor: string | null;
  auditor: string | null;
  type: string;
  callDate: string;
  auditDate: string;
  qualityPct: number;
  finalPct: number;
  hasFatal: boolean;
  feedbackStatus: string;
  feedbackSecurity: FeedbackSecurity;
  rows: AuditRow[];
  catScores: Record<string, CategoryScore>;
};

export type QmsParameterStat = {
  name: string;
  score: number;
  max: number;
  avg: number;
};

export type QmsCategoryStat = QmsParameterStat;

export type QmsEntityMetricRow = {
  entity: string;
  metric: string;
  score: number;
  samples: number;
};

export type QmsTeamStat = {
  team: string;
  avg: number;
  count: number;
};

export type QmsAgentStat = {
  agent: string;
  avg: number;
  count: number;
};

export type QmsAuditorStat = {
  name: string;
  count: number;
  avg: number;
  passRate: number;
};

export type QmsKpis = {
  total_audits: number;
  overall_avg: number;
  fatal_count: number;
  critical_count: number;
  medium_count: number;
  low_count: number;
  issue_sev_low: number;
  issue_sev_medium: number;
  issue_sev_critical: number;
  issue_sev_na: number;
  call_score: number;
  chat_score: number;
  call_count: number;
  chat_count: number;
  fb_done: number;
  fb_pending: number;
  fb_disputed: number;
  week1: number;
  week2: number;
  below_80: number;
  btw_80_90: number;
  btw_90_95: number;
  above_95: number;
};

export type QmsAnalyticsData = {
  kpis: QmsKpis;
  params: QmsParameterStat[];
  categories: QmsCategoryStat[];
  teams: QmsTeamStat[];
  bottom_agents: QmsAgentStat[];
  top_agents: QmsAgentStat[];
  auditors: QmsAuditorStat[];
  fatal_by_team: { team: string; count: number }[];
  team_param_breakdown: QmsEntityMetricRow[];
  team_cat_breakdown: QmsEntityMetricRow[];
  agent_param_breakdown: QmsEntityMetricRow[];
  agent_cat_breakdown: QmsEntityMetricRow[];
  auditor_param_breakdown: QmsEntityMetricRow[];
  auditor_cat_breakdown: QmsEntityMetricRow[];
};

const MIN_AGENT_AUDITS = 3;

export function scoreColorClass(score: number): string {
  if (score >= 95) return "qms-tone--excellent";
  if (score >= 90) return "qms-tone--good";
  if (score >= 80) return "qms-tone--fair";
  return "qms-tone--critical";
}

export function summaryChipClass(score: number): string {
  if (score >= 95) return "qms-summary-chip--excellent";
  if (score >= 90) return "qms-summary-chip--good";
  if (score >= 80) return "qms-summary-chip--fair";
  return "qms-summary-chip--critical";
}

export function scoreStatusLabel(score: number): string {
  if (score >= 95) return "Excellent";
  if (score >= 90) return "Good";
  if (score >= 80) return "Fair";
  return "Critical";
}

function avg(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, v) => sum + v, 0) / values.length;
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

function parseMetricDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(y, m - 1, d);
}

function recordMetricDate(record: AnalyticsAuditRecord): Date {
  return parseMetricDate(
    resolveMetricDate(record.auditDate, record.callDate)
  );
}

type MetricAccumulator = {
  displayName: string;
  scoreSum: number;
  maxSum: number;
  count: number;
};

function upsertMetricAccumulator(
  map: Map<string, MetricAccumulator>,
  key: string,
  displayName: string,
  score: number,
  max: number
) {
  if (!key) return;
  const entry = map.get(key) ?? {
    displayName,
    scoreSum: 0,
    maxSum: 0,
    count: 0,
  };
  entry.displayName = pickDisplayName(entry.displayName, displayName);
  entry.scoreSum += score;
  entry.maxSum += max;
  entry.count += 1;
  map.set(key, entry);
}

function metricStatsFromAccumulators(
  map: Map<string, MetricAccumulator>
): QmsParameterStat[] {
  return Array.from(map.values())
    .map((data) => {
      const score =
        data.maxSum > 0 ? round1((data.scoreSum / data.maxSum) * 100) : 0;
      const avgRaw = data.count > 0 ? round1(data.scoreSum / data.count) : 0;
      const maxTypical =
        data.count > 0 ? round1(data.maxSum / data.count) : 0;
      return {
        name: data.displayName,
        score,
        max: maxTypical,
        avg: avgRaw,
      };
    })
    .sort((a, b) => b.score - a.score);
}

function categoryContributionsForRecord(
  record: AnalyticsAuditRecord
): Map<string, { displayName: string; pct: number }> {
  const entries = new Map<string, { displayName: string; pct: number }>();
  const catScores = record.catScores ?? {};

  if (Object.keys(catScores).length > 0) {
    for (const [rawName, cat] of Object.entries(catScores)) {
      if (cat.max <= 0) continue;
      const key = canonicalCategoryKey(rawName);
      if (!key) continue;
      entries.set(key, {
        displayName: canonicalCategoryLabel(rawName),
        pct: (cat.scored / cat.max) * 100,
      });
    }
    return entries;
  }

  const bucket = new Map<
    string,
    { displayName: string; scoreSum: number; maxSum: number }
  >();

  for (const row of record.rows) {
    if (row.sel === "NA" || row.max <= 0) continue;
    const rawName = row.cat?.trim();
    if (!rawName) continue;
    const key = canonicalCategoryKey(rawName);
    const entry = bucket.get(key) ?? {
      displayName: canonicalCategoryLabel(rawName),
      scoreSum: 0,
      maxSum: 0,
    };
    entry.scoreSum += row.score;
    entry.maxSum += row.max;
    bucket.set(key, entry);
  }

  for (const [key, data] of bucket) {
    entries.set(key, {
      displayName: canonicalCategoryLabel(data.displayName),
      pct: data.maxSum > 0 ? (data.scoreSum / data.maxSum) * 100 : 0,
    });
  }

  return entries;
}

function computeRowMetricStats(
  records: AnalyticsAuditRecord[],
  metricKey: "parameter" | "category",
  aggregation: AnalyticsAggregationOptions = DEFAULT_AGGREGATION_OPTIONS
): QmsParameterStat[] {
  if (metricKey === "category") {
    const byKey = new Map<
      string,
      { displayName: string; pctSum: number; count: number }
    >();

    for (const record of records) {
      for (const [key, contribution] of categoryContributionsForRecord(record)) {
        const entry = byKey.get(key) ?? {
          displayName: contribution.displayName,
          pctSum: 0,
          count: 0,
        };
        entry.displayName = canonicalCategoryLabel(
          pickDisplayName(entry.displayName, contribution.displayName)
        );
        entry.pctSum += contribution.pct;
        entry.count += 1;
        byKey.set(key, entry);
      }
    }

    return Array.from(byKey.values())
      .map((data) => ({
        name: data.displayName,
        score: data.count > 0 ? round1(data.pctSum / data.count) : 0,
        max: 100,
        avg: data.count > 0 ? round1(data.pctSum / data.count) : 0,
      }))
      .sort((a, b) => b.score - a.score);
  }

  const byKey = new Map<string, MetricAccumulator>();

  for (const record of records) {
    for (const row of record.rows) {
      if (row.sel === "NA" || row.max <= 0) continue;
      const key = resolveParameterGroupKey(
        row,
        aggregation.mergeParametersAcrossInteractionTypes
      );
      upsertMetricAccumulator(
        byKey,
        key,
        row.name?.trim() || row.id,
        row.score,
        row.max
      );
    }
  }

  return metricStatsFromAccumulators(byKey);
}

function computeParameterStats(
  records: AnalyticsAuditRecord[],
  aggregation: AnalyticsAggregationOptions = DEFAULT_AGGREGATION_OPTIONS
): QmsParameterStat[] {
  return computeRowMetricStats(records, "parameter", aggregation);
}

function computeCategoryStats(
  records: AnalyticsAuditRecord[],
  aggregation: AnalyticsAggregationOptions = DEFAULT_AGGREGATION_OPTIONS
): QmsCategoryStat[] {
  return computeRowMetricStats(records, "category", aggregation);
}

function computeEntityMetricBreakdown(
  records: AnalyticsAuditRecord[],
  entityKey: "team" | "agent" | "auditor",
  dimension: "parameter" | "category",
  aggregation: AnalyticsAggregationOptions = DEFAULT_AGGREGATION_OPTIONS
): QmsEntityMetricRow[] {
  const buckets = new Map<
    string,
    Map<string, MetricAccumulator | { displayName: string; pctSum: number; count: number }>
  >();

  for (const record of records) {
    let entity: string | null = null;
    if (entityKey === "team") {
      entity = record.supervisor?.trim() || "Unassigned";
    } else if (entityKey === "agent") {
      entity = record.agent?.trim() || null;
    } else {
      entity = record.auditor?.trim() || null;
    }
    if (!entity) continue;

    if (!buckets.has(entity)) {
      buckets.set(entity, new Map());
    }
    const metricMap = buckets.get(entity)!;

    if (dimension === "category") {
      for (const [key, contribution] of categoryContributionsForRecord(record)) {
        const entry =
          (metricMap.get(key) as {
            displayName: string;
            pctSum: number;
            count: number;
          } | undefined) ?? {
            displayName: contribution.displayName,
            pctSum: 0,
            count: 0,
          };
        entry.displayName = canonicalCategoryLabel(
          pickDisplayName(entry.displayName, contribution.displayName)
        );
        entry.pctSum += contribution.pct;
        entry.count += 1;
        metricMap.set(key, entry);
      }
      continue;
    }

    for (const row of record.rows) {
      if (row.sel === "NA" || row.max <= 0) continue;
      const key = resolveParameterGroupKey(
        row,
        aggregation.mergeParametersAcrossInteractionTypes
      );
      upsertMetricAccumulator(
        metricMap as Map<string, MetricAccumulator>,
        key,
        row.name?.trim() || row.id,
        row.score,
        row.max
      );
    }
  }

  const rows: QmsEntityMetricRow[] = [];
  for (const [entity, metricMap] of buckets) {
    for (const [, data] of metricMap) {
      if ("pctSum" in data) {
        rows.push({
          entity,
          metric: data.displayName,
          score: data.count > 0 ? round1(data.pctSum / data.count) : 0,
          samples: data.count,
        });
        continue;
      }

      rows.push({
        entity,
        metric: data.displayName,
        score:
          data.maxSum > 0
            ? round1((data.scoreSum / data.maxSum) * 100)
            : 0,
        samples: data.count,
      });
    }
  }

  return rows.sort((a, b) => {
    const entityCmp = a.entity.localeCompare(b.entity, undefined, {
      sensitivity: "base",
    });
    if (entityCmp !== 0) return entityCmp;
    return b.score - a.score;
  });
}

function computeAgentStats(records: AnalyticsAuditRecord[]): QmsAgentStat[] {
  const byAgent = new Map<string, number[]>();

  for (const record of records) {
    const list = byAgent.get(record.agent) ?? [];
    list.push(record.qualityPct);
    byAgent.set(record.agent, list);
  }

  return Array.from(byAgent.entries())
    .map(([agent, scores]) => ({
      agent,
      avg: round1(avg(scores)),
      count: scores.length,
    }))
    .filter((a) => a.count >= MIN_AGENT_AUDITS);
}

function computeTeamStats(records: AnalyticsAuditRecord[]): QmsTeamStat[] {
  const byTeam = new Map<string, number[]>();

  for (const record of records) {
    const team = record.supervisor?.trim() || "Unassigned";
    const list = byTeam.get(team) ?? [];
    list.push(record.qualityPct);
    byTeam.set(team, list);
  }

  return Array.from(byTeam.entries())
    .map(([team, scores]) => ({
      team,
      avg: round1(avg(scores)),
      count: scores.length,
    }))
    .sort((a, b) => b.count - a.count);
}

function computeAuditorStats(records: AnalyticsAuditRecord[]): QmsAuditorStat[] {
  const byAuditor = new Map<string, { scores: number[]; pass: number }>();

  for (const record of records) {
    if (!record.auditor) continue;
    const entry = byAuditor.get(record.auditor) ?? { scores: [], pass: 0 };
    entry.scores.push(record.qualityPct);
    if (!record.hasFatal && record.qualityPct >= PASS_RATE_QUALITY_THRESHOLD) {
      entry.pass += 1;
    }
    byAuditor.set(record.auditor, entry);
  }

  return Array.from(byAuditor.entries())
    .map(([name, data]) => ({
      name,
      count: data.scores.length,
      avg: round1(avg(data.scores)),
      passRate:
        data.scores.length > 0
          ? Math.round((data.pass / data.scores.length) * 100)
          : 0,
    }))
    .sort((a, b) => b.count - a.count);
}

function computeFatalByTeam(
  records: AnalyticsAuditRecord[]
): { team: string; count: number }[] {
  const counts = new Map<string, number>();

  for (const record of records) {
    if (!record.hasFatal) continue;
    const team = record.supervisor?.trim() || "Unassigned";
    counts.set(team, (counts.get(team) ?? 0) + 1);
  }

  return Array.from(counts.entries())
    .map(([team, count]) => ({ team, count }))
    .sort((a, b) => b.count - a.count);
}

function computeAgentBands(agentStats: QmsAgentStat[]) {
  return {
    below_80: agentStats.filter((a) => a.avg < 80).length,
    btw_80_90: agentStats.filter((a) => a.avg >= 80 && a.avg < 90).length,
    btw_90_95: agentStats.filter((a) => a.avg >= 90 && a.avg < 95).length,
    above_95: agentStats.filter((a) => a.avg >= 95).length,
  };
}

function computeIssueSeverityCounts(records: AnalyticsAuditRecord[]) {
  let low = 0;
  let medium = 0;
  let critical = 0;
  let na = 0;

  for (const record of records) {
    switch (record.feedbackSecurity) {
      case "Low":
        low++;
        break;
      case "Medium":
        medium++;
        break;
      case "Critical":
        critical++;
        break;
      default:
        na++;
        break;
    }
  }

  return { low, medium, critical, na };
}

function computeWeekSplit(records: AnalyticsAuditRecord[], now = new Date()) {
  const month = now.getMonth();
  const year = now.getFullYear();
  let week1 = 0;
  let week2 = 0;

  for (const record of records) {
    const date = recordMetricDate(record);
    if (date.getMonth() !== month || date.getFullYear() !== year) continue;
    if (date.getDate() <= 15) week1++;
    else week2++;
  }

  return { week1, week2 };
}

export function computeQmsAnalytics(
  records: AnalyticsAuditRecord[],
  now = new Date(),
  aggregation: AnalyticsAggregationOptions = DEFAULT_AGGREGATION_OPTIONS
): QmsAnalyticsData {
  const total = records.length;
  const overallAvg = total > 0 ? round1(avg(records.map((r) => r.qualityPct))) : 0;

  const callRecords = records.filter((r) => r.type === "Call");
  const chatRecords = records.filter((r) => r.type === "Chat");

  const fatalCount = records.filter((r) => r.hasFatal).length;
  const criticalCount = records.filter(
    (r) => !r.hasFatal && r.qualityPct < 60
  ).length;
  const mediumCount = records.filter(
    (r) => !r.hasFatal && r.qualityPct >= 60 && r.qualityPct < 80
  ).length;
  const lowCount = records.filter(
    (r) => !r.hasFatal && r.qualityPct >= 80
  ).length;

  const fbDone = records.filter(
    (r) =>
      r.feedbackStatus === "Shared" ||
      r.feedbackStatus === "Acknowledged"
  ).length;
  const fbDisputed = records.filter(
    (r) => r.feedbackStatus === "Disputed"
  ).length;
  const fbPending = records.filter(
    (r) => r.feedbackStatus === "Pending"
  ).length;

  const issueSeverity = computeIssueSeverityCounts(records);

  const agentStats = computeAgentStats(records);
  const bands = computeAgentBands(agentStats);
  const weekSplit = computeWeekSplit(records, now);

  const teams = computeTeamStats(records);
  const sortedAgentsAsc = [...agentStats].sort((a, b) => a.count - b.count);
  const sortedAgentsDesc = [...agentStats].sort((a, b) => b.count - a.count);

  return {
    kpis: {
      total_audits: total,
      overall_avg: overallAvg,
      fatal_count: fatalCount,
      critical_count: criticalCount,
      medium_count: mediumCount,
      low_count: lowCount,
      issue_sev_low: issueSeverity.low,
      issue_sev_medium: issueSeverity.medium,
      issue_sev_critical: issueSeverity.critical,
      issue_sev_na: issueSeverity.na,
      call_score:
        callRecords.length > 0
          ? round1(avg(callRecords.map((r) => r.qualityPct)))
          : 0,
      chat_score:
        chatRecords.length > 0
          ? round1(avg(chatRecords.map((r) => r.qualityPct)))
          : 0,
      call_count: callRecords.length,
      chat_count: chatRecords.length,
      fb_done: fbDone,
      fb_pending: fbPending,
      fb_disputed: fbDisputed,
      week1: weekSplit.week1,
      week2: weekSplit.week2,
      ...bands,
    },
    params: computeParameterStats(records, aggregation),
    categories: computeCategoryStats(records, aggregation),
    teams,
    bottom_agents: sortedAgentsAsc.slice(0, 10),
    top_agents: sortedAgentsDesc.slice(0, 10),
    auditors: computeAuditorStats(records),
    fatal_by_team: computeFatalByTeam(records),
    team_param_breakdown: computeEntityMetricBreakdown(
      records,
      "team",
      "parameter",
      aggregation
    ),
    team_cat_breakdown: computeEntityMetricBreakdown(
      records,
      "team",
      "category",
      aggregation
    ),
    agent_param_breakdown: computeEntityMetricBreakdown(
      records,
      "agent",
      "parameter",
      aggregation
    ),
    agent_cat_breakdown: computeEntityMetricBreakdown(
      records,
      "agent",
      "category",
      aggregation
    ),
    auditor_param_breakdown: computeEntityMetricBreakdown(
      records,
      "auditor",
      "parameter",
      aggregation
    ),
    auditor_cat_breakdown: computeEntityMetricBreakdown(
      records,
      "auditor",
      "category",
      aggregation
    ),
  };
}
