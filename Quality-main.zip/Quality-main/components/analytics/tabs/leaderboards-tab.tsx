"use client";

import { useMemo, useState } from "react";
import type { LeaderboardAnalytics } from "@/lib/audit/leaderboard-metrics";
import type { AnalyticsSortOrder } from "@/lib/audit/analytics-sort";
import { sortByNumber } from "@/lib/audit/analytics-sort";
import {
  QmsCard,
  QmsEmpty,
  QmsSectionTitle,
  QmsViewToggle,
  scoreHex,
} from "@/components/analytics/qms-primitives";
import {
  DataTablePanel,
  usePaginatedRows,
} from "@/components/primitives/data-table-panel";

type LeaderboardsTabProps = {
  data: LeaderboardAnalytics;
};

const VIEWS = [
  { id: "overview", label: "Overview" },
  { id: "agents", label: "Agents" },
  { id: "supervisors", label: "Teams" },
  { id: "auditors", label: "Auditors" },
  { id: "reasons", label: "Reasons" },
] as const;

type ViewId = (typeof VIEWS)[number]["id"];

function LeaderboardTable({
  rows,
  title,
  sortOrder,
}: {
  rows: LeaderboardAnalytics["agents"];
  title: string;
  sortOrder: AnalyticsSortOrder;
}) {
  const sortedRows = useMemo(
    () => sortByNumber(rows, (row) => row.quality, sortOrder),
    [rows, sortOrder]
  );
  const pagination = usePaginatedRows(sortedRows);

  if (rows.length === 0) {
    return <QmsEmpty message={`No ${title.toLowerCase()} data available yet.`} />;
  }

  return (
    <QmsCard>
      <QmsSectionTitle
        title={`${title} rankings`}
        sub={`Sorted ${sortOrder === "desc" ? "high to low" : "low to high"}`}
      />
      <DataTablePanel
        pagination={pagination}
        renderTable={(slice) => (
        <table className="ui-table qms-table platform-leaderboard platform-report-table platform-report-table--expanded">
          <thead>
            <tr>
              <th>Rank</th>
              <th>Name</th>
              <th>Avg quality</th>
              <th>Fatal rate</th>
              <th>Fatals</th>
              <th>Audits</th>
              <th>Top fatal reasons</th>
            </tr>
          </thead>
          <tbody>
            {slice.map((row, index) => {
              const rank = pagination.start + index - 1;
              return (
              <tr key={row.name}>
                <td className="qms-cell-rank">
                  {rank < 3 ? `${rank + 1}` : `#${rank + 1}`}
                </td>
                <td className="qms-cell-strong">{row.name}</td>
                <td
                  className="qms-cell-accent"
                  style={{ color: scoreHex(row.quality) }}
                >
                  {row.quality}%
                </td>
                <td
                  className={
                    row.fatalRate > 10
                      ? "qms-cell-negative"
                      : undefined
                  }
                >
                  {row.fatalRate}%
                </td>
                <td className="qms-cell-negative">{row.fatals}</td>
                <td>{row.count}</td>
                <td>
                  <div className="platform-tag-list">
                    {row.fatalDetails.length > 0 ? (
                      row.fatalDetails.slice(0, 2).map((detail) => (
                        <span key={detail} className="platform-tag platform-tag--danger">
                          {detail}
                        </span>
                      ))
                    ) : (
                      <span className="platform-tag platform-tag--muted">
                        Clean
                      </span>
                    )}
                    {row.fatalDetails.length > 2 && (
                      <span className="platform-tag platform-tag--muted">
                        +{row.fatalDetails.length - 2}
                      </span>
                    )}
                  </div>
                </td>
              </tr>
              );
            })}
          </tbody>
        </table>
        )}
      />
    </QmsCard>
  );
}

function ParamAreas({
  items,
  tone,
  title,
  sub,
}: {
  items: LeaderboardAnalytics["weakParams"];
  tone: "danger" | "success";
  title: string;
  sub: string;
}) {
  return (
    <QmsCard className={`platform-param-card platform-param-card--${tone}`}>
      <QmsSectionTitle title={title} sub={sub} />
      <div className="platform-param-list">
        {items.length === 0 ? (
          <p className="platform-empty platform-empty--inline">
            No parameter data yet.
          </p>
        ) : (
          items.map((item) => (
            <div key={item.name} className="platform-param-row">
              <div className="platform-param-row__head">
                <span className="platform-param-row__name">
                  {item.name}
                  <em>{item.cat}</em>
                </span>
                <strong
                  style={{
                    color: scoreHex(item.pct),
                  }}
                >
                  {item.pct}%
                </strong>
              </div>
              <div className="platform-param-row__track">
                <div
                  className={`platform-param-row__fill platform-param-row__fill--${tone}`}
                  style={{ width: `${item.pct}%` }}
                />
              </div>
            </div>
          ))
        )}
      </div>
    </QmsCard>
  );
}

export function LeaderboardsTab({
  data,
  sortOrder,
}: LeaderboardsTabProps & { sortOrder: AnalyticsSortOrder }) {
  const [view, setView] = useState<ViewId>("overview");

  const dataset =
    view === "agents"
      ? data.agents
      : view === "supervisors"
        ? data.supervisors
        : view === "auditors"
          ? data.auditors
          : view === "reasons"
            ? data.reasons
            : [];

  const title =
    view === "agents"
      ? "Agent"
      : view === "supervisors"
        ? "Team"
        : view === "auditors"
          ? "Auditor"
          : view === "reasons"
            ? "Reason"
            : "";

  return (
    <div className="qms-tab">
      <QmsViewToggle
        value={view}
        onChange={(id) => setView(id as ViewId)}
        options={[...VIEWS]}
      />

      {view === "overview" ? (
        <>
          <div className="qms-panels qms-panels--2">
            <ParamAreas
              items={data.weakParams}
              tone="danger"
              title="Parameter drill-down"
              sub="Bottom 5 performing parameters"
            />
            <ParamAreas
              items={data.strongParams}
              tone="success"
              title="Excellence zone"
              sub="Top performing compliance parameters"
            />
          </div>
          <LeaderboardTable rows={data.agents} title="Agent" sortOrder={sortOrder} />
        </>
      ) : (
        <LeaderboardTable rows={dataset} title={title} sortOrder={sortOrder} />
      )}
    </div>
  );
}
